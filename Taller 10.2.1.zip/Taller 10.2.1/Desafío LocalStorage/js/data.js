document.getElementById("data").innerHTML = localStorage.getItem("data");
